
 <!DOCTYPE html>
<html lang="en">

<head>
    <title>Prime Assets Group | Deposit</title>
    <?php echo $__env->make('user.layouts.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="dark-sidenav">
    <!-- Left Sidenav -->
    <?php echo $__env->make('user.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end left-sidenav-->

    <div class="page-wrapper">

        <!-- Top Bar Start -->
        <?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Top Bar End -->
        <div class="page-content">
            <div>
                    <div>
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="row">
                            <div class="col">
                                <h4 class="page-title">Deposit</h4>
                            </div>
                            <div class="col-auto align-self-center"><a href="#" class="btn btn-sm btn-outline-secondary"
                                    id="Dash_Date"><span class="day-name" id="Day_Name">Today:</span>&nbsp; <span
                                        class=""
                                        id=" Select_date"></span> <i
                                        data-feather="calendar" class="align-self-center icon-xs ml-1"></i>
                                </a></div>
                        </div>
                    </div>
                </div>
            </div>

                <div class="row">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="pricingTable1 text-center"><img src="<?php echo e(asset('dash/images/bitcoin.svg')); ?>" alt=""
                            class=""
                                        height=" 100">
                        <h6 class="title1 py-3 mt-2 mb-0">Bitcoin</h6>
                        <ul class="list-unstyled pricing-content-2">
                        </ul>
                        <hr class="hr-dashed my-4">
                        <div class="text-center">
                        </div><a href="#" data-toggle="modal" data-target="#btc-fund-modal"
                            class="btn btn-primary btn-block btn-skew btn-outline-dashed py-2"><span>Deposit</span></a>
                    </div>
                    <!--end pricingTable-->
                </div>
                <!--end card-body-->
            </div>
            <!--end card-->
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="pricingTable1 text-center"><img src="<?php echo e(asset('dash/images/ethereum.svg')); ?>" alt=""
                            class=""
                                        height=" 100">
                        <h6 class="title1 py-3 mt-2 mb-0">Ethereum</h6>
                        <ul class="list-unstyled pricing-content-2">
                        </ul>
                        <hr class="hr-dashed my-4">
                        <div class="text-center">
                        </div><a href="#" data-toggle="modal" data-target="#eth-fund-modal"
                            class="btn btn-primary btn-block btn-skew btn-outline-dashed py-2"><span>Deposit</span></a>
                    </div>
                    <!--end pricingTable-->
                </div>
                <!--end card-body-->
            </div>
            <!--end card-->
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="pricingTable1 text-center"><img src="<?php echo e(asset('dash/images/bitcoin-cash.svg')); ?>" alt=""
                            class=""
                                        height=" 100">
                        <h6 class="title1 py-3 mt-2 mb-0">Bitcoin Cash</h6>
                        <ul class="list-unstyled pricing-content-2">
                        </ul>
                        <hr class="hr-dashed my-4">
                        <div class="text-center">
                        </div><a href="#" data-toggle="modal" data-target="#bch-fund-modal"
                            class="btn btn-primary btn-block btn-skew btn-outline-dashed py-2"><span>Deposit</span></a>
                    </div>
                    <!--end pricingTable-->
                </div>
                <!--end card-body-->
            </div>
            <!--end card-->
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="pricingTable1 text-center"><img src="<?php echo e(asset('dash/images/tether.svg')); ?>" alt=""
                            class=""
                                        height=" 100">
                        <h6 class="title1 py-3 mt-2 mb-0">USDT</h6>
                        <ul class="list-unstyled pricing-content-2">
                        </ul>
                        <hr class="hr-dashed my-4">
                        <div class="text-center">
                        </div><a href="#" data-toggle="modal" data-target="#usdt-fund-modal"
                            class="btn btn-primary btn-block btn-skew btn-outline-dashed py-2"><span>Deposit</span></a>
                    </div>
                    <!--end pricingTable-->
                </div>
                <!--end card-body-->
            </div>
            <!--end card-->
        </div>
    </div>

        <!--end col-->
    </div>
    <!--end row-->
    </div>
    </div>
    <!-- .page-content -->

          <?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\wamp64\www\switchassets.com\switchassets\switchassets\resources\views/user/deposit.blade.php ENDPATH**/ ?>