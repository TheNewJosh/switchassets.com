<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo.png')); ?>">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo e(asset('auth/css/bootstrap.min.css')); ?>">
<!-- Fontawesome CSS -->
<link rel="stylesheet" href="<?php echo e(asset('auth/css/fontawesome-all.min.css')); ?>">
<!-- Flaticon CSS -->
<link rel="stylesheet" href="<?php echo e(asset('auth/font/flaticon.css')); ?>">
<!-- Google Web Fonts -->
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap" rel="stylesheet">
<!-- Custom CSS -->
<link rel="stylesheet" href="<?php echo e(asset('auth/style.css')); ?>"><?php /**PATH C:\wamp64\www\switchassets.com\switchassets\switchassets\resources\views/auth/layouts/meta.blade.php ENDPATH**/ ?>