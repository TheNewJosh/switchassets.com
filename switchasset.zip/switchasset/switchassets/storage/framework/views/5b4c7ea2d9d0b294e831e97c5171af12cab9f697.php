<!-- jquery-->
<script src="<?php echo e(asset('auth/js/jquery-3.5.0.min.js')); ?>"></script>
<!-- Popper js -->
<script src="<?php echo e(asset('auth/js/popper.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('auth/js/bootstrap.min.js')); ?>"></script>
<!-- Imagesloaded js -->
<script src="<?php echo e(asset('auth/js/imagesloaded.pkgd.min.js')); ?>"></script>
<!-- Particles js -->
<script src="<?php echo e(asset('auth/js/particles.min.js')); ?>"></script>
<script src="<?php echo e(asset('auth/js/particles-1.js')); ?>"></script>
<!-- Validator js -->
<script src="<?php echo e(asset('auth/js/validator.min.js')); ?>"></script>
<!-- Custom Js -->
<script src="<?php echo e(asset('auth/js/main.js')); ?>"></script><?php /**PATH C:\wamp64\www\switchassets.com\switchassets\switchassets\resources\views/auth/layouts/footer.blade.php ENDPATH**/ ?>