<!doctype html>
<html class="no-js" lang="">

<head>
    <title>Prime Assets Group Asset Management </title>
    <?php echo $__env->make('auth.layouts.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <section class="fxt-template-animation fxt-template-layout21">
        <!-- Animation Start Here -->
        <div id="particles-js"></div>
        
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-xl-6 col-lg-7 col-sm-12 col-12 fxt-bg-color">
                <div class="fxt-content">
                    <div class="fxt-header">
                        
                        <p>Create an account.</p>
                    </div>
                    <div class="fxt-form">
                        <form method="POST" action="<?php echo e(route('register')); ?>">                          
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="referrer" <?php if(isset($_GET['id'])){ ?> value="<?= $_GET['id'] ?>" <?php }else{ ?> value="<?php echo e(old('referrer')); ?>" <?php } ?> >

                            <div class="form-group">
                                <div class="fxt-transformY-50 fxt-transition-delay-1">
                                    <input type="text" id="name" class="form-control" name="name" placeholder="Full Name"
                                        value="<?php echo e(old('name')); ?>" required />
                                </div>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <div class="fxt-transformY-50 fxt-transition-delay-1">
                                    <input type="email" id="email" class="form-control" name="email" placeholder="Email"
                                        value="<?php echo e(old('email')); ?>" required />
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <div class="fxt-transformY-50 fxt-transition-delay-1">
                                    <input type="tel" id="phone" class="form-control" name="phone"
                                        placeholder="Phone Number" value="<?php echo e(old('phone')); ?>" required />
                                </div>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                    <div class="fxt-transformY-50 fxt-transition-delay-1">
                                        <input type="number" class="form-control" name="referrer_id"
                                            placeholder="Referrer ID" value="<?php echo e(old('referrer_id')); ?>" />
                                    </div>
                                    <?php $__errorArgs = ['referrer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="form-text text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <div class="form-group">
                                <div class="fxt-transformY-50 fxt-transition-delay-2">
                                    <input id="password" type="password" class="form-control" name="password"
                                        placeholder="Password" required />
                                    <i toggle="#password" class="fa fa-fw fa-eye toggle-password field-icon"></i>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <div class="fxt-transformY-50 fxt-transition-delay-2">
                                    <input id="password" type="password" class="form-control" name="password_confirmation"
                                        placeholder="Confirm Password" required />
                                    <i toggle="#password" class="fa fa-fw fa-eye toggle-password field-icon"></i>
                                </div>
                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <div class="fxt-transformY-50 fxt-transition-delay-1">
                                    <select class="form-control" name="country">
                                        <option value="Afganistan" <?php if(old('country') == 'Afganistan'): ?> selected <?php endif; ?> >Afghanistan</option>
                                        <option value="Albania" <?php if(old('country') == 'Albania'): ?> selected <?php endif; ?> >Albania</option>
                                        <option value="Algeria" <?php if(old('country') == 'Algeria'): ?> selected <?php endif; ?> >Algeria</option>
                                        <option value="American Samoa" <?php if(old('country') == 'American Samoa'): ?> selected <?php endif; ?> >American Samoa</option>
                                        <option value="Andorra" <?php if(old('country') == 'Andorra'): ?> selected <?php endif; ?> >Andorra</option>
                                        <option value="Angola" <?php if(old('country') == 'Angola'): ?> selected <?php endif; ?> >Angola</option>
                                        <option value="Anguilla" <?php if(old('country') == 'Anguilla'): ?> selected <?php endif; ?> >Anguilla</option>
                                        <option value="Antigua & Barbuda" <?php if(old('country') == 'Antigua & Barbuda'): ?> selected <?php endif; ?> >Antigua & Barbuda</option>
                                        <option value="Argentina" <?php if(old('country') == 'Argentina'): ?> selected <?php endif; ?> >Argentina</option>
                                        <option value="Armenia" <?php if(old('country') == 'Armenia'): ?> selected <?php endif; ?> >Armenia</option>
                                        <option value="Aruba" <?php if(old('country') == 'Aruba'): ?> selected <?php endif; ?> >Aruba</option>
                                        <option value="Australia" <?php if(old('country') == 'Australia'): ?> selected <?php endif; ?> >Australia</option>
                                        <option value="Austria" <?php if(old('country') == 'Austria'): ?> selected <?php endif; ?> >Austria</option>
                                        <option value="Azerbaijan" <?php if(old('country') == 'Azerbaijan'): ?> selected <?php endif; ?> >Azerbaijan</option>
                                        <option value="Bahamas" <?php if(old('country') == 'Bahamas'): ?> selected <?php endif; ?> >Bahamas</option>
                                        <option value="Bahrain" <?php if(old('country') == 'Bahrain'): ?> selected <?php endif; ?> >Bahrain</option>
                                        <option value="Bangladesh" <?php if(old('country') == 'Bangladesh'): ?> selected <?php endif; ?> >Bangladesh</option>
                                        <option value="Barbados" <?php if(old('country') == 'Barbados'): ?> selected <?php endif; ?> >Barbados</option>
                                        <option value="Belarus" <?php if(old('country') == 'Belarus'): ?> selected <?php endif; ?> >Belarus</option>
                                        <option value="Belgium" <?php if(old('country') == 'Belgium'): ?> selected <?php endif; ?> >Belgium</option>
                                        <option value="Belize" <?php if(old('country') == 'Belize'): ?> selected <?php endif; ?> >Belize</option>
                                        <option value="Benin" <?php if(old('country') == 'Benin'): ?> selected <?php endif; ?> >Benin</option>
                                        <option value="Bermuda" <?php if(old('country') == 'Bermuda'): ?> selected <?php endif; ?> >Bermuda</option>
                                        <option value="Bhutan" <?php if(old('country') == 'Bhutan'): ?> selected <?php endif; ?> >Bhutan</option>
                                        <option value="Bolivia" <?php if(old('country') == 'Bolivia'): ?> selected <?php endif; ?> >Bolivia</option>
                                        <option value="Bonaire" <?php if(old('country') == 'Bonaire'): ?> selected <?php endif; ?> >Bonaire</option>
                                        <option value="Bosnia & Herzegovina" <?php if(old('country') == 'Bosnia & Herzegovina'): ?> selected <?php endif; ?> >Bosnia & Herzegovina</option>
                                        <option value="Botswana" <?php if(old('country') == 'Botswana'): ?> selected <?php endif; ?> >Botswana</option>
                                        <option value="Brazil" <?php if(old('country') == 'Brazil'): ?> selected <?php endif; ?> >Brazil</option>
                                        <option value="British Indian Ocean Ter" <?php if(old('country') == 'British Indian Ocean Ter'): ?> selected <?php endif; ?> >British Indian Ocean Ter</option>
                                        <option value="Brunei" <?php if(old('country') == 'Brunei'): ?> selected <?php endif; ?> >Brunei</option>
                                        <option value="Bulgaria" <?php if(old('country') == 'Bulgaria'): ?> selected <?php endif; ?> >Bulgaria</option>
                                        <option value="Burkina Faso" <?php if(old('country') == 'Burkina Faso'): ?> selected <?php endif; ?> >Burkina Faso</option>
                                        <option value="Burundi" <?php if(old('country') == 'Burundi'): ?> selected <?php endif; ?> >Burundi</option>
                                        <option value="Cambodia" <?php if(old('country') == 'Cambodia'): ?> selected <?php endif; ?> >Cambodia</option>
                                        <option value="Cameroon" <?php if(old('country') == 'Cameroon'): ?> selected <?php endif; ?> >Cameroon</option>
                                        <option value="Canada" <?php if(old('country') == 'Canada'): ?> selected <?php endif; ?> >Canada</option>
                                        <option value="Canary Islands" <?php if(old('country') == 'Canary Islands'): ?> selected <?php endif; ?> >Canary Islands</option>
                                        <option value="Cape Verde" <?php if(old('country') == 'Cape Verde'): ?> selected <?php endif; ?> >Cape Verde</option>
                                        <option value="Cayman Islands" <?php if(old('country') == 'Cayman Islands'): ?> selected <?php endif; ?> >Cayman Islands</option>
                                        <option value="Central African Republic" <?php if(old('country') == 'Central African Republic'): ?> selected <?php endif; ?> >Central African Republic</option>
                                        <option value="Chad" <?php if(old('country') == 'Chad'): ?> selected <?php endif; ?> >Chad</option>
                                        <option value="Channel Islands" <?php if(old('country') == 'Channel Islands'): ?> selected <?php endif; ?> >Channel Islands</option>
                                        <option value="Chile" <?php if(old('country') == 'Chile'): ?> selected <?php endif; ?> >Chile</option>
                                        <option value="China" <?php if(old('country') == 'China'): ?> selected <?php endif; ?> >China</option>
                                        <option value="Christmas Island" <?php if(old('country') == 'Christmas Island'): ?> selected <?php endif; ?> >Christmas Island</option>
                                        <option value="Cocos Island" <?php if(old('country') == 'Cocos Island'): ?> selected <?php endif; ?> >Cocos Island</option>
                                        <option value="Colombia" <?php if(old('country') == 'Colombia'): ?> selected <?php endif; ?> >Colombia</option>
                                        <option value="Comoros" <?php if(old('country') == 'Comoros'): ?> selected <?php endif; ?> >Comoros</option>
                                        <option value="Congo" <?php if(old('country') == 'Congo'): ?> selected <?php endif; ?> >Congo</option>
                                        <option value="Cook Islands" <?php if(old('country') == 'Cook Islands'): ?> selected <?php endif; ?> >Cook Islands</option>
                                        <option value="Costa Rica" <?php if(old('country') == 'Costa Rica'): ?> selected <?php endif; ?> >Costa Rica</option>
                                        <option value="Cote DIvoire" <?php if(old('country') == 'Cote DIvoire'): ?> selected <?php endif; ?> >Cote DIvoire</option>
                                        <option value="Croatia" <?php if(old('country') == 'Croatia'): ?> selected <?php endif; ?> >Croatia</option>
                                        <option value="Cuba" <?php if(old('country') == 'Cuba'): ?> selected <?php endif; ?> >Cuba</option>
                                        <option value="Curaco" <?php if(old('country') == 'Curacao'): ?> selected <?php endif; ?> >Curacao</option>
                                        <option value="Cyprus" <?php if(old('country') == 'Cyprus'): ?> selected <?php endif; ?> >Cyprus</option>
                                        <option value="Czech Republic" <?php if(old('country') == 'Czech Republic'): ?> selected <?php endif; ?> >Czech Republic</option>
                                        <option value="Denmark" <?php if(old('country') == 'Denmark'): ?> selected <?php endif; ?> >Denmark</option>
                                        <option value="Djibouti" <?php if(old('country') == 'Djibouti'): ?> selected <?php endif; ?> >Djibouti</option>
                                        <option value="Dominica" <?php if(old('country') == 'Dominica'): ?> selected <?php endif; ?> >Dominica</option>
                                        <option value="Dominican Republic" <?php if(old('country') == 'Dominican Republic'): ?> selected <?php endif; ?> >Dominican Republic</option>
                                        <option value="East Timor" <?php if(old('country') == 'East Timor'): ?> selected <?php endif; ?> >East Timor</option>
                                        <option value="Ecuador" <?php if(old('country') == 'Ecuador'): ?> selected <?php endif; ?> >Ecuador</option>
                                        <option value="Egypt" <?php if(old('country') == 'Egypt'): ?> selected <?php endif; ?> >Egypt</option>
                                        <option value="El Salvador" <?php if(old('country') == 'El Salvador'): ?> selected <?php endif; ?> >El Salvador</option>
                                        <option value="Equatorial Guinea" <?php if(old('country') == 'Equatorial Guinea'): ?> selected <?php endif; ?> >Equatorial Guinea</option>
                                        <option value="Eritrea" <?php if(old('country') == 'Eritrea'): ?> selected <?php endif; ?> >Eritrea</option>
                                        <option value="Estonia" <?php if(old('country') == 'Estonia'): ?> selected <?php endif; ?> >Estonia</option>
                                        <option value="Ethiopia" <?php if(old('country') == 'Ethiopia'): ?> selected <?php endif; ?> >Ethiopia</option>
                                        <option value="Falkland Islands" <?php if(old('country') == 'Falkland Islands'): ?> selected <?php endif; ?> >Falkland Islands</option>
                                        <option value="Faroe Islands" <?php if(old('country') == '>Faroe Islands'): ?> selected <?php endif; ?> >Faroe Islands</option>
                                        <option value="Fiji" <?php if(old('country') == 'Fiji'): ?> selected <?php endif; ?> >Fiji</option>
                                        <option value="Finland" <?php if(old('country') == 'Finland'): ?> selected <?php endif; ?> >Finland</option>
                                        <option value="France" <?php if(old('country') == 'France'): ?> selected <?php endif; ?> >France</option>
                                        <option value="French Guiana" <?php if(old('country') == 'French Guiana'): ?> selected <?php endif; ?> >French Guiana</option>
                                        <option value="French Polynesia" <?php if(old('country') == 'French Polynesia'): ?> selected <?php endif; ?> >French Polynesia</option>
                                        <option value="French Southern Ter" <?php if(old('country') == 'French Southern Te'): ?> selected <?php endif; ?> >French Southern Ter</option>
                                        <option value="Gabon" <?php if(old('country') == 'Gabon'): ?> selected <?php endif; ?> >Gabon</option>
                                        <option value="Gambia" <?php if(old('country') == 'Gambia'): ?> selected <?php endif; ?> >Gambia</option>
                                        <option value="Georgia" <?php if(old('country') == 'Georgia'): ?> selected <?php endif; ?> >Georgia</option>
                                        <option value="Germany" <?php if(old('country') == 'Germany'): ?> selected <?php endif; ?> >Germany</option>
                                        <option value="Ghana" <?php if(old('country') == 'Ghana'): ?> selected <?php endif; ?> >Ghana</option>
                                        <option value="Gibraltar" <?php if(old('country') == 'Gibraltar'): ?> selected <?php endif; ?> >Gibraltar</option>
                                        <option value="Great Britain" <?php if(old('country') == 'Great Britain'): ?> selected <?php endif; ?> >Great Britain</option>
                                        <option value="Greece" <?php if(old('country') == 'Greece'): ?> selected <?php endif; ?> >Greece</option>
                                        <option value="Greenland" <?php if(old('country') == 'Greenland'): ?> selected <?php endif; ?> >Greenland</option>
                                        <option value="Grenada" <?php if(old('country') == 'Grenada'): ?> selected <?php endif; ?> >Grenada</option>
                                        <option value="Guadeloupe" <?php if(old('country') == 'Guadeloupe'): ?> selected <?php endif; ?> >Guadeloupe</option>
                                        <option value="Guam" <?php if(old('country') == 'Guam'): ?> selected <?php endif; ?> >Guam</option>
                                        <option value="Guatemala" <?php if(old('country') == 'Guatemala'): ?> selected <?php endif; ?> >Guatemala</option>
                                        <option value="Guinea" <?php if(old('country') == 'Guinea'): ?> selected <?php endif; ?> >Guinea</option>
                                        <option value="Guyana" <?php if(old('country') == 'Guyana'): ?> selected <?php endif; ?> >Guyana</option>
                                        <option value="Haiti" <?php if(old('country') == 'Haiti'): ?> selected <?php endif; ?> >Haiti</option>
                                        <option value="Hawaii" <?php if(old('country') == 'Hawaii'): ?> selected <?php endif; ?> >Hawaii</option>
                                        <option value="Honduras" <?php if(old('country') == 'Honduras'): ?> selected <?php endif; ?> >Honduras</option>
                                        <option value="Hong Kong" <?php if(old('country') == 'Hong Kong'): ?> selected <?php endif; ?> >Hong Kong</option>
                                        <option value="Hungary" <?php if(old('country') == 'Hungary'): ?> selected <?php endif; ?> >Hungary</option>
                                        <option value="Iceland" <?php if(old('country') == 'Iceland'): ?> selected <?php endif; ?> >Iceland</option>
                                        <option value="Indonesia" <?php if(old('country') == 'Indonesia'): ?> selected <?php endif; ?> >Indonesia</option>
                                        <option value="India" <?php if(old('country') == 'India'): ?> selected <?php endif; ?> >India</option>
                                        <option value="Iran" <?php if(old('country') == 'Iran'): ?> selected <?php endif; ?> >Iran</option>
                                        <option value="Iraq" <?php if(old('country') == 'Iraq'): ?> selected <?php endif; ?> >Iraq</option>
                                        <option value="Ireland" <?php if(old('country') == 'Ireland'): ?> selected <?php endif; ?> >Ireland</option>
                                        <option value="Isle of Man" <?php if(old('country') == 'Isle of Man'): ?> selected <?php endif; ?> >Isle of Man</option>
                                        <option value="Israel" <?php if(old('country') == 'Israel'): ?> selected <?php endif; ?> >Israel</option>
                                        <option value="Italy" <?php if(old('country') == 'Italy'): ?> selected <?php endif; ?> >Italy</option>
                                        <option value="Jamaica" <?php if(old('country') == 'Jamaica'): ?> selected <?php endif; ?> >Jamaica</option>
                                        <option value="Japan" <?php if(old('country') == 'Japan'): ?> selected <?php endif; ?> >Japan</option>
                                        <option value="Jordan" <?php if(old('country') == 'Jordan'): ?> selected <?php endif; ?> >Jordan</option>
                                        <option value="Kazakhstan" <?php if(old('country') == 'Kazakhstan'): ?> selected <?php endif; ?> >Kazakhstan</option>
                                        <option value="Kenya" <?php if(old('country') == 'Kenya'): ?> selected <?php endif; ?> >Kenya</option>
                                        <option value="Kiribati" <?php if(old('country') == 'Kiribati'): ?> selected <?php endif; ?> >Kiribati</option>
                                        <option value="Korea North" <?php if(old('country') == 'Korea North'): ?> selected <?php endif; ?> >Korea North</option>
                                        <option value="Korea Sout" <?php if(old('country') == 'Korea South'): ?> selected <?php endif; ?> >Korea South</option>
                                        <option value="Kuwait" <?php if(old('country') == 'Kuwait'): ?> selected <?php endif; ?> >Kuwait</option>
                                        <option value="Kyrgyzstan" <?php if(old('country') == 'Kyrgyzstan'): ?> selected <?php endif; ?> >Kyrgyzstan</option>
                                        <option value="Laos" <?php if(old('country') == 'Laos'): ?> selected <?php endif; ?> >Laos</option>
                                        <option value="Latvia" <?php if(old('country') == 'Latvia'): ?> selected <?php endif; ?> >Latvia</option>
                                        <option value="Lebanon" <?php if(old('country') == 'Lebanon'): ?> selected <?php endif; ?> >Lebanon</option>
                                        <option value="Lesotho" <?php if(old('country') == 'Lesotho'): ?> selected <?php endif; ?> >Lesotho</option>
                                        <option value="Liberia" <?php if(old('country') == 'Liberia'): ?> selected <?php endif; ?> >Liberia</option>
                                        <option value="Libya" <?php if(old('country') == 'Libya'): ?> selected <?php endif; ?> >Libya</option>
                                        <option value="Liechtenstein" <?php if(old('country') == 'Liechtenstein'): ?> selected <?php endif; ?> >Liechtenstein</option>
                                        <option value="Lithuania" <?php if(old('country') == 'Lithuania'): ?> selected <?php endif; ?> >Lithuania</option>
                                        <option value="Luxembourg" <?php if(old('country') == 'Luxembourg'): ?> selected <?php endif; ?> >Luxembourg</option>
                                        <option value="Macau" <?php if(old('country') == 'Macau'): ?> selected <?php endif; ?> >Macau</option>
                                        <option value="Macedonia" <?php if(old('country') == 'Macedonia'): ?> selected <?php endif; ?> >Macedonia</option>
                                        <option value="Madagascar" <?php if(old('country') == 'Madagascar'): ?> selected <?php endif; ?> >Madagascar</option>
                                        <option value="Malaysia" <?php if(old('country') == 'Malaysia'): ?> selected <?php endif; ?> >Malaysia</option>
                                        <option value="Malawi" <?php if(old('country') == 'Malawi'): ?> selected <?php endif; ?> >Malawi</option>
                                        <option value="Maldives" <?php if(old('country') == 'Maldives'): ?> selected <?php endif; ?> >Maldives</option>
                                        <option value="Mali" <?php if(old('country') == 'Mali'): ?> selected <?php endif; ?> >Mali</option>
                                        <option value="Malta" <?php if(old('country') == 'Malta'): ?> selected <?php endif; ?> >Malta</option>
                                        <option value="Marshall Islands" <?php if(old('country') == 'Marshall Islands'): ?> selected <?php endif; ?> >Marshall Islands</option>
                                        <option value="Martinique" <?php if(old('country') == 'Martinique'): ?> selected <?php endif; ?> >Martinique</option>
                                        <option value="Mauritania" <?php if(old('country') == 'Mauritania'): ?> selected <?php endif; ?> >Mauritania</option>
                                        <option value="Mauritius" <?php if(old('country') == 'Mauritius'): ?> selected <?php endif; ?> >Mauritius</option>
                                        <option value="Mayotte" <?php if(old('country') == 'Mayotte'): ?> selected <?php endif; ?> >Mayotte</option>
                                        <option value="Mexico" <?php if(old('country') == 'Mexico'): ?> selected <?php endif; ?> >Mexico</option>
                                        <option value="Midway Islands" <?php if(old('country') == 'Midway Islands'): ?> selected <?php endif; ?> >Midway Islands</option>
                                        <option value="Moldova" <?php if(old('country') == 'Moldova'): ?> selected <?php endif; ?> >Moldova</option>
                                        <option value="Monaco" <?php if(old('country') == 'Monaco'): ?> selected <?php endif; ?> >Monaco</option>
                                        <option value="Mongolia" <?php if(old('country') == 'Mongolia'): ?> selected <?php endif; ?> >Mongolia</option>
                                        <option value="Montserrat" <?php if(old('country') == 'Montserrat'): ?> selected <?php endif; ?> >Montserrat</option>
                                        <option value="Morocco" <?php if(old('country') == 'Morocco'): ?> selected <?php endif; ?> >Morocco</option>
                                        <option value="Mozambique" <?php if(old('country') == 'Mozambique'): ?> selected <?php endif; ?> >Mozambique</option>
                                        <option value="Myanmar" <?php if(old('country') == 'Myanmar'): ?> selected <?php endif; ?> >Myanmar</option>
                                        <option value="Nambia" <?php if(old('country') == 'Nambia'): ?> selected <?php endif; ?> >Nambia</option>
                                        <option value="Nauru" <?php if(old('country') == 'Nauru'): ?> selected <?php endif; ?> >Nauru</option>
                                        <option value="Nepal" <?php if(old('country') == 'Nepal'): ?> selected <?php endif; ?> >Nepal</option>
                                        <option value="Netherland Antilles" <?php if(old('country') == 'Netherland Antilles'): ?> selected <?php endif; ?> >Netherland Antilles</option>
                                        <option value="Netherlands" <?php if(old('country') == 'Netherlands'): ?> selected <?php endif; ?> >Netherlands (Holland, Europe)</option>
                                        <option value="Nevis" <?php if(old('country') == 'Nevis'): ?> selected <?php endif; ?> >Nevis</option>
                                        <option value="New Caledonia" <?php if(old('country') == 'New Caledonia'): ?> selected <?php endif; ?> >New Caledonia</option>
                                        <option value="New Zealand" <?php if(old('country') == 'New Zealand'): ?> selected <?php endif; ?> >New Zealand</option>
                                        <option value="Nicaragua" <?php if(old('country') == 'Nicaragua'): ?> selected <?php endif; ?> >Nicaragua</option>
                                        <option value="Niger" <?php if(old('country') == 'Niger'): ?> selected <?php endif; ?> >Niger</option>
                                        <option value="Nigeria" <?php if(old('country') == 'Nigeria'): ?> selected <?php endif; ?> >Nigeria</option>
                                        <option value="Niue" <?php if(old('country') == 'Niue'): ?> selected <?php endif; ?> >Niue</option>
                                        <option value="Norfolk Island" <?php if(old('country') == 'Norfolk Island'): ?> selected <?php endif; ?> >Norfolk Island</option>
                                        <option value="Norway" <?php if(old('country') == 'Norway'): ?> selected <?php endif; ?> >Norway</option>
                                        <option value="Oman" <?php if(old('country') == 'Oman'): ?> selected <?php endif; ?> >Oman</option>
                                        <option value="Pakistan" <?php if(old('country') == 'Pakistan'): ?> selected <?php endif; ?> >Pakistan</option>
                                        <option value="Palau Island" <?php if(old('country') == 'Palau Island'): ?> selected <?php endif; ?> >Palau Island</option>
                                        <option value="Palestine" <?php if(old('country') == 'Palestine'): ?> selected <?php endif; ?> >Palestine</option>
                                        <option value="Panama" <?php if(old('country') == 'Panama'): ?> selected <?php endif; ?> >Panama</option>
                                        <option value="Papua New Guinea" <?php if(old('country') == 'Papua New Guinea'): ?> selected <?php endif; ?> >Papua New Guinea</option>
                                        <option value="Paraguay" <?php if(old('country') == 'Paraguay'): ?> selected <?php endif; ?> >Paraguay</option>
                                        <option value="Peru" <?php if(old('country') == 'Peru'): ?> selected <?php endif; ?> >Peru</option>
                                        <option value="Phillipines" <?php if(old('country') == 'Philippines'): ?> selected <?php endif; ?> >Philippines</option>
                                        <option value="Pitcairn Island" <?php if(old('country') == 'Pitcairn Island'): ?> selected <?php endif; ?> >Pitcairn Island</option>
                                        <option value="Poland" <?php if(old('country') == 'Poland'): ?> selected <?php endif; ?> >Poland</option>
                                        <option value="Portugal" <?php if(old('country') == 'Portugal'): ?> selected <?php endif; ?> >Portugal</option>
                                        <option value="Puerto Rico" <?php if(old('country') == 'Puerto Rico'): ?> selected <?php endif; ?> >Puerto Rico</option>
                                        <option value="Qatar" <?php if(old('country') == 'Qatar'): ?> selected <?php endif; ?> >Qatar</option>
                                        <option value="Republic of Montenegro" <?php if(old('country') == 'Republic of Montenegro'): ?> selected <?php endif; ?> >Republic of Montenegro</option>
                                        <option value="Republic of Serbia" <?php if(old('country') == 'Republic of Serbia'): ?> selected <?php endif; ?> >Republic of Serbia</option>
                                        <option value="Reunion" <?php if(old('country') == 'Reunion'): ?> selected <?php endif; ?> >Reunion</option>
                                        <option value="Romania" <?php if(old('country') == 'Romania'): ?> selected <?php endif; ?> >Romania</option>
                                        <option value="Russia" <?php if(old('country') == 'Russia'): ?> selected <?php endif; ?> >Russia</option>
                                        <option value="Rwanda" <?php if(old('country') == 'Rwanda'): ?> selected <?php endif; ?> >Rwanda</option>
                                        <option value="St Barthelemy" <?php if(old('country') == 'St Barthelemy'): ?> selected <?php endif; ?> >St Barthelemy</option>
                                        <option value="St Eustatius" <?php if(old('country') == 'St Eustatius'): ?> selected <?php endif; ?> >St Eustatius</option>
                                        <option value="St Helena" <?php if(old('country') == 'St Helena'): ?> selected <?php endif; ?> >St Helena</option>
                                        <option value="St Kitts-Nevis" <?php if(old('country') == 'St Kitts-Nevis'): ?> selected <?php endif; ?> >St Kitts-Nevis</option>
                                        <option value="St Lucia" <?php if(old('country') == 'St Lucia'): ?> selected <?php endif; ?> >St Lucia</option>
                                        <option value="St Maarten" <?php if(old('country') == 'St Maarten'): ?> selected <?php endif; ?> >St Maarten</option>
                                        <option value="St Pierre & Miquelon" <?php if(old('country') == 'St Pierre & Miquelon'): ?> selected <?php endif; ?> >St Pierre & Miquelon</option>
                                        <option value="St Vincent & Grenadines" <?php if(old('country') == 'St Vincent & Grenadines'): ?> selected <?php endif; ?> >St Vincent & Grenadines</option>
                                        <option value="Saipan" <?php if(old('country') == 'Saipan'): ?> selected <?php endif; ?> >Saipan</option>
                                        <option value="Samoa" <?php if(old('country') == 'Samoa'): ?> selected <?php endif; ?> >Samoa</option>
                                        <option value="Samoa American" <?php if(old('country') == 'Samoa American'): ?> selected <?php endif; ?> >Samoa American</option>
                                        <option value="San Marino" <?php if(old('country') == 'San Marino'): ?> selected <?php endif; ?> >San Marino</option>
                                        <option value="Sao Tome & Principe" <?php if(old('country') == 'Sao Tome & Principe'): ?> selected <?php endif; ?> >Sao Tome & Principe</option>
                                        <option value="Saudi Arabia" <?php if(old('country') == 'Saudi Arabia'): ?> selected <?php endif; ?> >Saudi Arabia</option>
                                        <option value="Senegal" <?php if(old('country') == 'Senegal'): ?> selected <?php endif; ?> >Senegal</option>
                                        <option value="Seychelles" <?php if(old('country') == 'Seychelles'): ?> selected <?php endif; ?> >Seychelles</option>
                                        <option value="Sierra Leone" <?php if(old('country') == 'Sierra Leone'): ?> selected <?php endif; ?> >Sierra Leone</option>
                                        <option value="Singapore" <?php if(old('country') == 'Singapore'): ?> selected <?php endif; ?> >Singapore</option>
                                        <option value="Slovakia" <?php if(old('country') == 'Slovakia'): ?> selected <?php endif; ?> >Slovakia</option>
                                        <option value="Slovenia" <?php if(old('country') == 'Slovenia'): ?> selected <?php endif; ?> >Slovenia</option>
                                        <option value="Solomon Islands" <?php if(old('country') == 'Solomon Islands'): ?> selected <?php endif; ?> >Solomon Islands</option>
                                        <option value="Somalia" <?php if(old('country') == 'Somalia'): ?> selected <?php endif; ?> >Somalia</option>
                                        <option value="South Africa" <?php if(old('country') == 'South Africa'): ?> selected <?php endif; ?> >South Africa</option>
                                        <option value="Spain" <?php if(old('country') == 'Spain'): ?> selected <?php endif; ?> >Spain</option>
                                        <option value="Sri Lanka" <?php if(old('country') == 'Sri Lanka'): ?> selected <?php endif; ?> >Sri Lanka</option>
                                        <option value="Sudan" <?php if(old('country') == 'Sudan'): ?> selected <?php endif; ?> >Sudan</option>
                                        <option value="Suriname" <?php if(old('country') == 'Suriname'): ?> selected <?php endif; ?> >Suriname</option>
                                        <option value="Swaziland" <?php if(old('country') == 'Swaziland'): ?> selected <?php endif; ?> >Swaziland</option>
                                        <option value="Sweden" <?php if(old('country') == 'Sweden'): ?> selected <?php endif; ?> >Sweden</option>
                                        <option value="Switzerland" <?php if(old('country') == 'Switzerland'): ?> selected <?php endif; ?> >Switzerland</option>
                                        <option value="Syria" <?php if(old('country') == 'Syria'): ?> selected <?php endif; ?> >Syria</option>
                                        <option value="Tahiti" <?php if(old('country') == 'Tahiti'): ?> selected <?php endif; ?> >Tahiti</option>
                                        <option value="Taiwan" <?php if(old('country') == 'Taiwan'): ?> selected <?php endif; ?> >Taiwan</option>
                                        <option value="Tajikistan" <?php if(old('country') == 'Tajikistan'): ?> selected <?php endif; ?> >Tajikistan</option>
                                        <option value="Tanzania" <?php if(old('country') == 'Tanzania'): ?> selected <?php endif; ?> >Tanzania</option>
                                        <option value="Thailand" <?php if(old('country') == 'Thailand'): ?> selected <?php endif; ?> >Thailand</option>
                                        <option value="Togo" <?php if(old('country') == 'Togo'): ?> selected <?php endif; ?> >Togo</option>
                                        <option value="Tokelau" <?php if(old('country') == 'Tokelau'): ?> selected <?php endif; ?> >Tokelau</option>
                                        <option value="Tonga" <?php if(old('country') == 'Tonga'): ?> selected <?php endif; ?> >Tonga</option>
                                        <option value="Trinidad & Tobago" <?php if(old('country') == 'Trinidad & Tobago'): ?> selected <?php endif; ?> >Trinidad & Tobago</option>
                                        <option value="Tunisia" <?php if(old('country') == 'Tunisia'): ?> selected <?php endif; ?> >Tunisia</option>
                                        <option value="Turkey" <?php if(old('country') == 'Turkey'): ?> selected <?php endif; ?> >Turkey</option>
                                        <option value="Turkmenistan" <?php if(old('country') == 'Turkmenistan'): ?> selected <?php endif; ?> >Turkmenistan</option>
                                        <option value="Turks & Caicos Is" <?php if(old('country') == 'Turks & Caicos Is'): ?> selected <?php endif; ?> >Turks & Caicos Is</option>
                                        <option value="Tuvalu" <?php if(old('country') == 'Tuvalu'): ?> selected <?php endif; ?> >Tuvalu</option>
                                        <option value="Uganda" <?php if(old('country') == 'Uganda'): ?> selected <?php endif; ?> >Uganda</option>
                                        <option value="United Kingdom" <?php if(old('country') == 'United Kingdom'): ?> selected <?php endif; ?> >United Kingdom</option>
                                        <option value="Ukraine" <?php if(old('country') == 'Ukraine'): ?> selected <?php endif; ?> >Ukraine</option>
                                        <option value="United Arab Erimates" <?php if(old('country') == 'United Arab Emirates'): ?> selected <?php endif; ?> >United Arab Emirates</option>
                                        <option value="United States of America" <?php if(old('country') == 'United States of America'): ?> selected <?php endif; ?> >United States of America</option>
                                        <option value="Uraguay" <?php if(old('country') == 'Uruguay'): ?> selected <?php endif; ?> >Uruguay</option>
                                        <option value="Uzbekistan" <?php if(old('country') == 'Uzbekistan'): ?> selected <?php endif; ?> >Uzbekistan</option>
                                        <option value="Vanuatu" <?php if(old('country') == 'Vanuatu'): ?> selected <?php endif; ?> >Vanuatu</option>
                                        <option value="Vatican City State" <?php if(old('country') == 'Vatican City State'): ?> selected <?php endif; ?> >Vatican City State</option>
                                        <option value="Venezuela" <?php if(old('country') == 'Venezuela'): ?> selected <?php endif; ?> >Venezuela</option>
                                        <option value="Vietnam" <?php if(old('country') == 'Vietnam'): ?> selected <?php endif; ?> >Vietnam</option>
                                        <option value="Virgin Islands (Brit)" <?php if(old('country') == 'Virgin Islands (Brit)'): ?> selected <?php endif; ?> >Virgin Islands (Brit)</option>
                                        <option value="Virgin Islands (USA)" <?php if(old('country') == 'Virgin Islands (USA)'): ?> selected <?php endif; ?> >Virgin Islands (USA)</option>
                                        <option value="Wake Island" <?php if(old('country') == 'Wake Island'): ?> selected <?php endif; ?> >Wake Island</option>
                                        <option value="Wallis & Futana Is" <?php if(old('country') == 'Wallis & Futana Is'): ?> selected <?php endif; ?> >Wallis & Futana Is</option>
                                        <option value="Yemen" <?php if(old('country') == 'Yemen'): ?> selected <?php endif; ?> >Yemen</option>
                                        <option value="Zaire" <?php if(old('country') == 'Zaire'): ?> selected <?php endif; ?> >Zaire</option>
                                        <option value="Zambia" <?php if(old('country') == 'Zambia'): ?> selected <?php endif; ?> >Zambia</option>
                                        <option value="Zimbabwe" <?php if(old('country') == 'Zimbabwe'): ?> selected <?php endif; ?> >Zimbabwe</option>
                                    </select>
                                        
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="fxt-transformY-50 fxt-transition-delay-3">
                                    <div class="fxt-checkbox-area">
                                        <div class="checkbox">
                                            <input id="checkbox1" type="checkbox" required>
                                            <label for="checkbox1">I accept <a class="text-primary" href="<?php echo e(url('terms')); ?>">Terms
                                                    and conditions</a></label>
                                        </div>
                                        <a href="<?php echo e(url('reset')); ?>" class="switcher-text">Forgot Password</a>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="fxt-transformY-50 fxt-transition-delay-4">
                                    <button style="background-color: #08237e" type="submit" class="fxt-btn-fill">Create
                                        Account</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="fxt-footer">
                        <div class="fxt-transformY-50 fxt-transition-delay-9">
                            <p>Already have an account?<a href="<?php echo e(url('login')); ?>" class="switcher-text2 inline-text">Log in</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </section>
    
    <?php echo $__env->make('auth.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</body>

</html><?php /**PATH C:\wamp64\www\switchassets.com\switchassets\switchassets\resources\views/auth/register.blade.php ENDPATH**/ ?>