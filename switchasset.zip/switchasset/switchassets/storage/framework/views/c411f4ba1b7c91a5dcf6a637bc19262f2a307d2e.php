<!doctype html>
<html class="no-js" lang="">
<head>
    
    <title>Switch Assets Group Asset Management </title>
    <?php echo $__env->make('auth.layouts.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</head>

<body>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <section class="fxt-template-animation fxt-template-layout21">
        <!-- Animation Start Here -->
        <div id="particles-js"></div>
        
     <div class="container">
         <div class="row align-items-center justify-content-center">
             <div class="col-xl-6 col-lg-7 col-sm-12 col-12 fxt-bg-color">
                 <div class="fxt-content">
                     <div class="fxt-header">
                         
                         <p>Login into your dashboard.</p>
                     </div>
                     <div class="fxt-form">
                         <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>                            
                             <div class="form-group">
                                 <div class="fxt-transformY-50 fxt-transition-delay-1">
                                     <input type="email" id="email" class="form-control" name="email" placeholder="Email"
                                         value="" required />
                                 </div>
                                 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                             </div>
                             <div class="form-group">
                                 <div class="fxt-transformY-50 fxt-transition-delay-2">
                                     <input id="password" type="password" class="form-control" name="password"
                                         placeholder="********" required />
                                     <i toggle="#password" class="fa fa-fw fa-eye toggle-password field-icon"></i>
                                 </div>
                             </div>
                             <div class="form-group">
                                 <div class="fxt-transformY-50 fxt-transition-delay-3">
                                     <div class="fxt-checkbox-area">
                                         <div class="checkbox">
                                             <input id="checkbox1" type="checkbox">
                                             <label for="checkbox1">Keep me logged in</label>
                                         </div>
                                         <a href="<?php echo e(url('reset')); ?>" class="switcher-text">Forgot Password</a>
                                     </div>
                                 </div>
                             </div>
                             <div class="form-group">
                                 <div class="fxt-transformY-50 fxt-transition-delay-4">
                                     <button style="background-color: #08237e" type="submit" class="fxt-btn-fill">Log in</button>
                                 </div>
                             </div>
                         </form>
                     </div>
                     <div class="fxt-footer">
                         <div class="fxt-transformY-50 fxt-transition-delay-9">
                             <p>Don't have an account?<a href="<?php echo e(url('register')); ?>" class="switcher-text2 inline-text">Register</a>
                             </p>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>

     </section>
    
     <?php echo $__env->make('auth.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     
</body>

</html><?php /**PATH C:\wamp64\www\switchassets.com\switchassets\switchassets\resources\views/auth/login.blade.php ENDPATH**/ ?>