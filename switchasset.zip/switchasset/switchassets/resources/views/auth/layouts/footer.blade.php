<!-- jquery-->
<script src="{{ asset('auth/js/jquery-3.5.0.min.js')}}"></script>
<!-- Popper js -->
<script src="{{ asset('auth/js/popper.min.js')}}"></script>
<!-- Bootstrap js -->
<script src="{{ asset('auth/js/bootstrap.min.js')}}"></script>
<!-- Imagesloaded js -->
<script src="{{ asset('auth/js/imagesloaded.pkgd.min.js')}}"></script>
<!-- Particles js -->
<script src="{{ asset('auth/js/particles.min.js')}}"></script>
<script src="{{ asset('auth/js/particles-1.js')}}"></script>
<!-- Validator js -->
<script src="{{ asset('auth/js/validator.min.js')}}"></script>
<!-- Custom Js -->
<script src="{{ asset('auth/js/main.js')}}"></script>