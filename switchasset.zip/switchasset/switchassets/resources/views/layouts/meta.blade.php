<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="fonts.googleapis.com/css4e134e13.html?family=Open+Sans:300,400,400i,800" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/vendor.css')}}">
    <link rel="stylesheet" href="{{ asset('css/custom.css')}}">
    <link rel="stylesheet" href="{{ asset('css/style-1.css')}}" id="template-skin">
    <link rel="icon" type="image/ico" href="{{ asset('images/favicon.html')}}">
    <link rel="icon" type="image/png" href="{{ asset('images/logo.png')}}">