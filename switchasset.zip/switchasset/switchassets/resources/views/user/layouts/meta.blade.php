<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
<meta content="" name="description">
<meta content="" name="author">
<meta http-equiv="X-UA-Compatible" content="IE=edge"><!-- App favicon -->
<link rel="shortcut icon" href="{{ asset('dash/images/logo.png')}}" />

<link href="{{ asset('dash/css/jquery-jvectormap-2.0.2.css')}}" rel="stylesheet">
<!-- App css -->
<link href="{{ asset('dash/css/custom.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/dashboard.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/select2.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/jquery-ui.min.css')}}" rel="stylesheet">
<link href="{{ asset('dash/css/icons.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/custom.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/metisMenu.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/daterangepicker.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/dropify.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/jquery.steps.css')}}" rel="stylesheet">
<link href="{{ asset('dash/css/mastercard.css')}}" rel="stylesheet" type="text/css">
<link href="{{ asset('dash/css/app.min.css')}}" rel="stylesheet" type="text/css">

<link href="{{ asset('dash/css/jquery.dataTables.min.css')}}" rel="stylesheet" type="text/css">  